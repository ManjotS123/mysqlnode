 const http = require('http');

console.log("running on http:localhost:3000");

http.createServer(function(req,res){
    res.write("<h1>Hello world.<h1>");
    res.end();
}).listen(3000);